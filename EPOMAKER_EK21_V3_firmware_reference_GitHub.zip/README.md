# EPOMAKER EK21 V3 firmware reference files

This folder contains an EPOMAKER EK21 **V3** firmware updater and its accompanying update instructions, preserved as supplied. It does not contain firmware source code.

## Compatibility warning

These files are **not verified for the older EPOMAKER EK21 identified as USB VID/PID `320F:5055`** (VIA usage `FF60:0061`, protocol 9, 4×12 matrix). Static inspection of this updater found target identifiers `248A:5B49` and an embedded payload path `V21-8373-VIA/EPOMAKER EK21/8278_three_mode_sdk.bin`. That target differs from `320F:5055`.

**Do not run this updater or flash its payload on a `320F:5055` keypad.** The updater was inspected as data only; it was not executed and no device was flashed.

## Contents

- `EPOMAKER-EK21-CS7385-V0102-20240822.exe` — vendor updater, version label `V0102`, dated 2024-08-22.
- `V3 version update instructions.docx` — accompanying V3 update instructions.
- `SHA256SUMS.txt` — SHA-256 hashes for the two files.

## Provenance and redistribution

The files were already present in the local EPOMAKER EK21 V3 firmware folder. No source-code repository or redistribution license was found alongside them. The included binaries and instructions remain third-party vendor materials; check EPOMAKER's permission and applicable terms before publishing them publicly. No license is granted by this package.

## Safety

This is an archival/reference package, not a recommendation to install firmware. Confirm the exact hardware revision and obtain a matching vendor package before any firmware operation. Never use this V3 package as a recovery image for the older `320F:5055` revision.
